import "./new-collections-header.css";

const NewCollectionHeader = () => {
  return (
    <div>
      <div className="new-collection-title">New collection</div>
      <div className="new-collection-sub">
        {" "}
        Contrary to popular belief, Lorem Ipsum is not simply random text. It
        has roots in a piece of classical Latin literature from 45 BC
      </div>
    </div>
  );
};

export default NewCollectionHeader;
